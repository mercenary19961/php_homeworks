<!DOCTYPE html>
<html>
<head>
    <title>Search Employee</title>
    <link rel="stylesheet" href="path/to/your/css/file.css">
</head>
<body>
    <h1>Search Employee</h1>

    <form action="search_results.php" method="post">
        <label for="employee_id">Employee ID:</label>
        <input type="text" id="employee_id" name="employee_id">
        <button type="submit">Search</button>
        <button type="button" onclick="window.location.href='admin_dashboard.php'">Cancel</button>
    </form>
</body>
</html>
