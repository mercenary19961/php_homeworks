<?php
require("config.php");

$employee_id = $_POST['employee_id'];
$query = "SELECT * FROM employees";
$params = [];

if (!empty($employee_id)) {
    $query .= " WHERE id = ?";
    $params[] = $employee_id;
}

$stmt = $conn->prepare($query);

if (!empty($employee_id)) {
    $stmt->bind_param("i", $employee_id);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Search Results</title>
    <link rel="stylesheet" href="path/to/your/css/file.css">
</head>
<body>
    <h1>Search Results</h1>

    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Salary</th>
                <th>Days Off</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['salary']; ?></td>
                <td><?php echo $row['daysoff']; ?></td>
                <td>
                    <a href="delete_employee.php?id=<?php echo $row['id']; ?>">Delete</a>
                    <a href="update_employee.php?id=<?php echo $row['id']; ?>">Update</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <button type="button" onclick="window.location.href='search_employee.php'">Back to Search</button>
    <button type="button" onclick="window.location.href='admin_dashboard.php'">Back to Dashboard</button>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
